#!/bin/bash
file="quotes.txt"
sed -i '/^[[:space:]]*$/d' $file
cat -n $file | sort -uk2 | sort -nk1 | cut -f2- > new.txt
cat new.txt > $file
rm new.txt
