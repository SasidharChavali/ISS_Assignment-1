#!/bin/bash
a='"'
file="quotes.txt"
sed -i '/^[[:space:]]*$/d' $file #removes empty lines
while read line
do
arr=${line##*~} # arr contains the author name
line=${line%%~*} # line contains the quote
echo "${arr} once said, "$a""$line""$a"."
done < "$file" > speech.txt




