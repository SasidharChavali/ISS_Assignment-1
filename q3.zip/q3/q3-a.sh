#!/bin/bash

c=(`ls -l $1`)
d=${c[4]}

echo "Size of file is $d bytes"