#!/bin/bash

b=`wc -l < $1`

echo "Total No.of lines in the file is $b"