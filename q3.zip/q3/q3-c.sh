#!/bin/bash

a=`wc -w < $1`

echo "Total No.of words in the file is $a" 