#!/bin/bash

b=`wc -l < $1`

awk 'NR==1, NR==b {print "Line No: " NR " - "NF}' $1