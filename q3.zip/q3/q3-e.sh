#!/bin/bash

echo "List of repeated words and frequency: "
grep -wo '[[:alnum:]]\+' $1 | sort | uniq -cd > output.txt
e=`wc -l < output.txt`
awk 'NR==1, NR==e {print $2 " : " $1}' output.txt
rm output.txt