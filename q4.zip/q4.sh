#!/bin/bash

echo "Enter the elements of array: "
read -a arr

b=${#arr[*]}

for ((i = 0; i<b; i++))
do
      
    for ((j = 0; j<b-i-1; j++))
    do
    
        if [[ ${arr[j]} -gt ${arr[j+1]} ]]
        then
            temp=${arr[j]}
            arr[j]=${arr[j+1]}  
            arr[j+1]=$temp
        fi
    done
done

echo ${arr[*]}
