#1/bin/bash

echo "Enter the String: "
read arr

b=${#arr}
echo "String in reverse: "

for ((i=b-1 ; i>=0; i--)) 
do
    echo -n ${arr:i:1}
done
echo
echo "Replacing letters in the reverse output with subsequent letter: "

for ((i=b-1 ; i>=0 ; i--))
do
    if [[ ${arr:i:1} == 'z' ]]
    then
        echo -n "a"
        continue
    fi
    y=$(echo "${arr:i:1}" | tr "{a-zA-Z}" "{b-zA-ZA}")
    echo -n $y
done 
echo
echo "Printing half string in reverse: "

a=$((b/2-1))

for ((i=a ; i>=0 ; i--))
do
    echo -n ${arr:i:1}
done    

for ((j=a+1 ; j<b ; j++))
do
    echo -n ${arr:j:1}
done
echo